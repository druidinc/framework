<?php

	defined('APPLICATION_ENV') || define('APPLICATION_ENV',(getenv('APPLICATION_ENV') ? getenv('APPLICATION_ENV'): 'PROD'));


	ini_set('display_errors', 1);
	ini_set('log_errors', 1);
	ini_set('error_log', dirname(__FILE__) . '/error_log.txt');
	error_reporting(E_ALL);


	/**
	 * WEB_ROOT_FOLDER is the name of the parent folder you created these 
	 * documents in.
	 */
	if(!defined('SERVER_ROOT'))
		define('SERVER_ROOT' , dirname(__FILE__));

   
	//set system path
	if(!defined('SYSTEM_PATH'))
		define('SYSTEM_PATH','framework');


	//check if system path is not deleted
	if(!is_dir(SYSTEM_PATH))
		die('System path invalid');


	//include Druid
	include SYSTEM_PATH . '/Druid.php';
?>